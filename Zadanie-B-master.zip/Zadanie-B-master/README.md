# Povinné zadanie B - Stránka (8.5.2016)
Vytvorenie stránky v HTML5, CSS, Bootstrap:

	Oboznámte sa so základmi tvorby súčasných webových aplikácií. Preštudujte si CSS, Bootstrap, HTML na stránkach W3C Schools alebo tutoriály iných autorov.

	Vyhľadajte voľne dostupnú šablónu HTML5 (One Page HTML5 Bootstrap Template alebo Parallax HTML5 Template Bootstrap) alebo použite niektorú z dostupných šablón v NetBeans.

	Vytvorte vzdialený repozitár na GitHube s názvom vybratej témy stránky.

	Upravte šablónu na jednu z nasledujúcich tém

	Osobná stránka

	Prezentácia vašej záverečnej práce

	Deň otvorených dverí

	Súťaž študentských projektov

	Iné podľa dohody

	Odporúčam použiť Netbeans (8.0/7.4), oboznámite sa tak s ďalšími  možnosťami tohto IDE.

	Nezabudnite čiastkové úlohy popísať v podobe používateľských príbehov v Pivotal Trackeri.

	Identifikujte aspoň 20 príbehov, ktoré postupne vyriešite.

	Všetky zmeny commitujte do vzdialeného repozitára na GitHube.

	Do tejto aktivity vložte link na vzdialený repozitár so stránkou, link na webovú stránku vo Vašom webovom priestore a komprimovanú verziu súborov vytvorenej stránky. 
